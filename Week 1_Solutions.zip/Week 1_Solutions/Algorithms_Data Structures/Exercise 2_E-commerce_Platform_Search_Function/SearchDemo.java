// SearchDemo.java

import java.util.Arrays;
import java.util.Comparator;

public class SearchDemo {

    // Linear Search by Product Name
    public static Product linearSearch(Product[] products, String name) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(name)) {
                return product;
            }
        }
        return null;
    }

    // Binary Search by Product Name
    public static Product binarySearch(Product[] products, String name) {
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            int result = products[mid].getProductName().compareToIgnoreCase(name);

            if (result == 0)
                return products[mid];
            else if (result < 0)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(102, "Shoes", "Footwear"),
            new Product(103, "Phone", "Electronics"),
            new Product(104, "Book", "Stationery"),
            new Product(105, "Keyboard", "Electronics")
        };

        System.out.println("🔍 Linear Search (Unsorted Array)");
        Product result1 = linearSearch(products, "Phone");
        System.out.println(result1 != null ? result1 : "Product not found");

        System.out.println("\n🔍 Binary Search (Sorted by Name)");
        Arrays.sort(products, Comparator.comparing(Product::getProductName));
        Product result2 = binarySearch(products, "Phone");
        System.out.println(result2 != null ? result2 : "Product not found");
    }
}
