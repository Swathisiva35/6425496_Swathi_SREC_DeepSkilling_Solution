// FinancialForecast.java

public class FinancialForecast {

    // Recursive method to calculate future value
    public static double forecastFutureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        return forecastFutureValue(initialValue, growthRate, years - 1) * (1 + growthRate);
    }

    public static void main(String[] args) {
        double initialInvestment = 1000.0; // Initial amount in rupees
        double annualGrowthRate = 0.10;    // 10% growth
        int years = 5;

        double futureValue = forecastFutureValue(initialInvestment, annualGrowthRate, years);

        System.out.printf("Future value after %d years: ₹%.2f%n", years, futureValue);
    }
}
