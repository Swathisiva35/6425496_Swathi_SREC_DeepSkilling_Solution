// Logger.java

public class Logger {

    // 1. Create a private static instance of the class
    private static Logger instance;

    // 2. Make the constructor private so no external class can instantiate
    private Logger() {
        System.out.println("Logger Initialized!");
    }

    // 3. Provide a public static method to get the instance
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();  // Create the instance if it doesn't exist
        }
        return instance;  // Return the same instance every time
    }

    // Sample log method
    public void log(String message) {
        System.out.println("[LOG]: " + message);
    }
}
